#ifndef TitanS_qtr8a_h
#define TitanS_qtr8a_h
#include "Arduino.h"

class TitanS_qtr8a
{
    public:
    TitanS_qtr8a(int emitter,int buzzer,int in1,int in2,int in3,int in4);
    void write_setup();
    void write_loop();

    private:
    int _emitter;
    int _buzzer;
    int _in1;
    int _in2;
    int _in3;
    int _in4;
    #define Kp 0.06
    #define Kd 4
    int sag_max_hiz=100;
    int sol_max_hiz=100;
    int sag_temel_hiz=70;
    int sol_temel_hiz=70;
    uint16_t sensor_degerleri[6];
    int son_hata = 0;
};
#endif