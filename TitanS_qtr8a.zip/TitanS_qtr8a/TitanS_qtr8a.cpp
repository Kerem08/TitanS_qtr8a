#include "TitanS_qtr8a.h"
#include "Arduino.h"
#include "QTRSensors.h"
QTRSensors qtr;
TitanS_qtr8a::TitanS_qtr8a(int emitter, int buzzer, int in1, int in2, int in3, int in4)
{
  pinMode(buzzer,OUTPUT);
  pinMode(in1,OUTPUT);
  pinMode(in2,OUTPUT);
  pinMode(in3,OUTPUT);
  pinMode(in4,OUTPUT);
  _emitter=emitter;
  _buzzer=buzzer;
  _in1=in1;
  _in2=in2;
  _in3=in3;
  _in4=in4;
}

void TitanS_qtr8a::write_setup()
{
  qtr.setTypeAnalog();
  qtr.setSensorPins((const uint8_t[]){A0, A1, A2, A3, A4, A5}, 6);
  qtr.setEmitterPin(_emitter);
  digitalWrite(_buzzer,HIGH);
  delay(100);
  digitalWrite(_buzzer,LOW);
  for (uint16_t i = 0; i < 400; i++)
  {
    qtr.calibrate();
  }
  delay(1000);
  digitalWrite(_buzzer,HIGH);
  delay(100);
  digitalWrite(_buzzer,LOW);
  delay(2000);
}


void TitanS_qtr8a::write_loop()
{
  uint16_t konum = qtr.readLineBlack(sensor_degerleri);
  int hata = konum - 3500;
  int motor_hizi = Kp * hata + Kd * (hata - son_hata);
  son_hata = hata;
  int sag_motor_hizi = sag_temel_hiz + motor_hizi;
  int sol_motor_hizi = sol_temel_hiz - motor_hizi;

  if (sag_motor_hizi > sag_max_hiz ) sag_motor_hizi = sag_max_hiz;
  if (sol_motor_hizi > sol_max_hiz ) sol_motor_hizi = sol_max_hiz;
  if (sag_motor_hizi < 0) sag_motor_hizi = 0;
  if (sol_motor_hizi < 0) sol_motor_hizi = 0;
  
    analogWrite(_in1, sol_motor_hizi);
    analogWrite(_in2, 0);

    analogWrite(_in3, 0);
    analogWrite(_in4, sag_motor_hizi);
}